package com.drfin.drfin_amoney.utils;

import android.content.Context;

public interface SelectCityStateInterface {
    void onGetStateOrCity(Context context, String flag, String name,String id);
}
