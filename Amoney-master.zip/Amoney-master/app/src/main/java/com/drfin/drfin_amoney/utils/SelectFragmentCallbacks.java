package com.drfin.drfin_amoney.utils;

import android.content.Context;

public interface SelectFragmentCallbacks {
    void onActionChange(Context context,String flag);
}
